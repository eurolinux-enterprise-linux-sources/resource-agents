SAP HANA System Replication (Scale-Up)
=====================================

File structure
--------------

- `ra` contains the actual resource agents, `SAPHana` and `SAPHanaTopology`;
- `tool` contains the Perl auxiliary library and tools

